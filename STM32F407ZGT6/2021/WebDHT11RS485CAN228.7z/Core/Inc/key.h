#ifndef _KEY_H_
#define _KEY_H_
#include "main.h"
#include "usart.h"
#include "freertos.h"
int get_keyValue(void);
void keyValue_Reset(void);
#endif
