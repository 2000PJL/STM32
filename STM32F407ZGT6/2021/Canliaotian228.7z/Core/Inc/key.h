#ifndef _KEY_H_
#define _KEY_H_
#include "main.h"
int get_keyValue(void);
void keyValue_Reset(void);
#endif
